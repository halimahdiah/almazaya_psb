<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing extends CI_Controller {

	function __construct()
	{
		parent::__construct();     
    }

    public function index()
	{
		$this->vars['content'] = 'admin/marketing/dashboard';
		$this->load->view('admin/index', $this->vars);
    }

    public function sekolah()
	{
		$this->vars['content'] = 'admin/marketing/sekolah';
		$this->load->view('admin/index', $this->vars);
    }

    public function registrasi()
	{
		$this->vars['content'] = 'admin/merketing/registrasi';
		$this->load->view('admin/index', $this->vars);
    }
}
?>