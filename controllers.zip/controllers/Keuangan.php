<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keuangan extends CI_Controller {

	function __construct()
	{
		parent::__construct();     
    }

    public function index()
	{
		$this->vars['content'] = 'admin/keuangan/dashboard';
		$this->load->view('admin/index', $this->vars);
    }

    public function spp()
	{
		$this->vars['content'] = 'admin/keuangan/spp';
		$this->load->view('admin/index', $this->vars);
    }

    public function registrasi()
	{
		$this->vars['content'] = 'admin/keuangan/registrasi';
		$this->load->view('admin/index', $this->vars);
    }
}
?>